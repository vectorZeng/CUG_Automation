#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>
bool MainWindow::myconnect()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("student.db");
    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("Cannot open database"),
            QObject::tr("Unable to establish a database connection.\n"
                        "This example needs SQLite support. Please read "
                        "the Qt SQL driver documentation for information how "
                        "to build it.\n\n"
                        "Click Cancel to exit."), QMessageBox::Cancel);
        return false;
    }
    return true;

}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    studentqrModel=new QSqlQueryModel(this);
    myconnect();

    QString scity ="武汉";
    QSqlQuery qr;
    qr.prepare("select * from student where scity = ?");
    qr.addBindValue(scity);
    qr.exec();
    studentqrModel->setQuery(qr);
    ui->tableView_3->setModel(studentqrModel);

    courseModel=new QSqlTableModel(this);
    courseModel->setTable("course");
    courseModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    //courseModel->setFilter("cno=100");
    courseModel->select();
    ui->tableView_2->setModel(courseModel);

    studentModel= new QSqlRelationalTableModel(this);
    studentModel->setTable("student");

    studentModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    studentModel->select();
    ui->tableView_1->setModel(studentModel);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_one_clicked()
{
    ui->one->setEnabled(false);
    ui->two->setEnabled(true);
    ui->three->setEnabled(true);
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_two_clicked()
{
    ui->two->setEnabled(false);
    ui->one->setEnabled(true);
    ui->three->setEnabled(true);
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_three_clicked()
{
    ui->two->setEnabled(true);
    ui->one->setEnabled(true);
    ui->three->setEnabled(false);
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_save_clicked()
{
    studentModel->database().transaction();
    if (studentModel->submitAll())
    {
        studentModel->database().commit();
    }
    else {
              studentModel->database().rollback();
              QMessageBox::warning(this, tr("Cached Table"),
                                   tr("The database reported an error: %1")
                                   .arg(studentModel->lastError().text()));
         }
}

void MainWindow::on_recall_clicked()
{
    studentModel->revertAll();
}
