#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "login.h"
#include<QSqlDatabase>
#include<QSqlTableModel>
#include<QtSql/QSqlQueryModel>
#include<QtSql/QSqlQuery>
#include<QtSql/QSqlRelationalTableModel>
#include<QtSql>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    bool myconnect();


private:
    QSqlTableModel* courseModel;
    QSqlRelationalTableModel* studentModel;
    QSqlQueryModel* studentqrModel;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_one_clicked();

    void on_two_clicked();

    void on_three_clicked();

    void on_save_clicked();

    void on_recall_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
