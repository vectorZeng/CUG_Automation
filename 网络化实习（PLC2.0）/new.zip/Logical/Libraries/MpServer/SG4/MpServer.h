/* Automation Studio generated header file */
/* Do not edit ! */
/* MpServer 5.21.0 */

#ifndef _MPSERVER_
#define _MPSERVER_
#ifdef __cplusplus
extern "C" 
{
#endif
#ifndef _MpServer_VERSION
#define _MpServer_VERSION 5.21.0
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif



#ifdef __cplusplus
};
#endif
#endif /* _MPSERVER_ */

