/* Automation Studio generated header file */
/* Do not edit ! */
/* ModbusTCP 2.08.2 */

#ifndef _MODBUSTCP_
#define _MODBUSTCP_
#ifdef __cplusplus
extern "C" 
{
#endif
#ifndef _ModbusTCP_VERSION
#define _ModbusTCP_VERSION 2.08.2
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
#ifdef _SG3
		#include "astime.h"
		#include "standard.h"
		#include "AsIecCon.h"
		#include "AsTCP.h"
#endif
#ifdef _SG4
		#include "astime.h"
		#include "standard.h"
		#include "AsIecCon.h"
		#include "AsTCP.h"
#endif
#ifdef _SGC
		#include "astime.h"
		#include "standard.h"
		#include "AsIecCon.h"
		#include "AsTCP.h"
#endif


/* Constants */
#ifdef _REPLACE_CONST
 #define MAX_MBTCP_ALLOWED_CLIENT_NUM 15U
 #define MAX_MBTCP_REGISTERS_NUM 49999U
 #define MAX_MBTCP_ALLOWED_CLIENT_CMD_NUM 20U
 #define MAX_MBTCP_REGISTERS_HANDLE_ONCE 127U
 #define MAX_MBTCP_SENDBUFF 263U
#else
 _GLOBAL_CONST unsigned char MAX_MBTCP_ALLOWED_CLIENT_NUM;
 _GLOBAL_CONST unsigned short MAX_MBTCP_REGISTERS_NUM;
 _GLOBAL_CONST unsigned char MAX_MBTCP_ALLOWED_CLIENT_CMD_NUM;
 _GLOBAL_CONST unsigned short MAX_MBTCP_REGISTERS_HANDLE_ONCE;
 _GLOBAL_CONST unsigned short MAX_MBTCP_SENDBUFF;
#endif




/* Datatypes and datatypes of function blocks */
typedef struct client_info_typ
{	unsigned long ident;
	unsigned short port;
	unsigned char ip_addr[18];
} client_info_typ;

typedef struct modbus_client_action_enable_typ
{	plcbit cyclic;
	plcbit single;
} modbus_client_action_enable_typ;

typedef struct modbus_client_action_param_typ
{	unsigned char type;
	unsigned short start_addr;
	unsigned short quantity;
	unsigned long p_pv;
	unsigned long timer;
} modbus_client_action_param_typ;

typedef struct modbus_client_cfg_typ
{	struct modbus_client_action_enable_typ action_enable[21];
	struct modbus_client_action_param_typ action_param[21];
} modbus_client_cfg_typ;

typedef struct modbus_server_unit_typ
{	unsigned long p_discrete_inputs[50000];
	unsigned long p_coils[50000];
	unsigned long p_input_registers[50000];
	unsigned long p_holding_registers[50000];
} modbus_server_unit_typ;

typedef struct modbus_server_cfg_typ
{	struct modbus_server_unit_typ unit;
} modbus_server_cfg_typ;

typedef struct recive_buff_typ
{	unsigned char byte[256];
} recive_buff_typ;

typedef struct MBclient
{
	/* VAR_INPUT (analog) */
	unsigned short port;
	plcstring server_ip_addr[19];
	struct modbus_client_cfg_typ* p_cfg;
	unsigned long receive_timeout;
	unsigned short serverPort;
	unsigned char unit_id;
	/* VAR_OUTPUT (analog) */
	unsigned short status;
	plcstring sErrorMsg[161];
	/* VAR (analog) */
	unsigned short step;
	struct TcpOpen tcp_open;
	struct TcpClient tcp_client;
	struct TcpSend tcp_send;
	struct TcpRecv tcp_recive;
	struct TcpClose tcp_close;
	unsigned char last_req;
	unsigned long recive_timer;
	unsigned long send_timer[21];
	unsigned long start_send_time[21];
	unsigned long start_receive_time;
	unsigned char send_buff[256];
	unsigned char recive_buff[256];
	unsigned short transaction_id;
	unsigned long wrong_message;
	/* VAR_INPUT (digital) */
	plcbit enable;
} MBclient_typ;

typedef struct MBserver
{
	/* VAR_INPUT (analog) */
	unsigned long TimeOut;
	unsigned short serverPort;
	struct modbus_server_cfg_typ* p_cfg;
	plcstring ipString[19];
	/* VAR_OUTPUT (analog) */
	unsigned short status;
	plcstring sErrorMsg[161];
	/* VAR (analog) */
	unsigned short step;
	unsigned char client_nr;
	struct client_info_typ client_info[16];
	unsigned char client_addr[18];
	unsigned char receive_index;
	unsigned char receive_index_old;
	struct TcpOpen tcp_open;
	struct TcpServer tcp_server;
	struct TcpSend tcp_send;
	struct TON_10ms tcp_recive_timer[16];
	struct TcpRecv tcp_recive[16];
	struct TcpClose tcp_close;
	unsigned char send_buff[264];
	struct recive_buff_typ recive_buff[16];
	struct TON_10ms fatal_wait_timer;
	struct TcpIoctl tcp_ioctl;
	/* VAR_INPUT (digital) */
	plcbit enable;
	/* VAR (digital) */
	plcbit exceedMaxClient;
	plcbit btcpSO_NOWAITING_SET;
} MBserver_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void MBclient(struct MBclient* inst);
_BUR_PUBLIC void MBserver(struct MBserver* inst);


#ifdef __cplusplus
};
#endif
#endif /* _MODBUSTCP_ */

