# 2-DOF Robotic Arm Model

**Credits:** https://youtu.be/pDiwAA1cnb0?feature=shared
