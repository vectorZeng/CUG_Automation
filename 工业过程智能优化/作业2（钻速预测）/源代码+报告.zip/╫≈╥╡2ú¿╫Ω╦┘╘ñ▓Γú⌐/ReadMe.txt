ROP_sn.mat 是原始数据
filt.mat 是处理后的数据
ML_model.mat 是四种效果最好的回归模型，包括随机森林模型、高斯过程回归模型、决策树和最小二乘核
rop_predict.m是程序
compare.xlsx是四个模型的指标对比
pics文件夹里的是运行结果的.eps矢量图